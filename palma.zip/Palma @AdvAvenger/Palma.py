import asyncio
import threading
import random
from pystyle import Colors, Box, Write, Center, Colorate, Anime
import time
import requests
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import whois
import os
import string
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
a=input(Colorate.Horizontal(Colors.yellow_to_green, ("Введите ключ активации Palma > ")))
if a!="palmagoodknowall":
	print(Colorate.Horizontal(Colors.yellow_to_green, (f"Неверный ключ активации / Ключ недействителен")))
	exit()
else:
	print(Colorate.Horizontal(Colors.yellow_to_green, (f"Успешно! запускаю программу...")))
def clear_console():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
clear_console()
print(Colorate.Horizontal(Colors.yellow_to_green, ("Palma | Version - [1.0] | Developer - @AdvAvenger")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┏━━━━━━━━━━━━━━━━━━━━━━━┓")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ 1 < Отправить миньонов┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ 2 < Потапать хомяка   ┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ 3 < Пельмешки на столе┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ 4 < Поиск по Б/Д куриц┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ 5 < Мануал по аноним- ┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┃ности                  ┃")))
print(Colorate.Horizontal(Colors.yellow_to_green, ("┗━━━━━━━━━━━━━━━━━━━━━━━┛")))
b = 1
x = 0
g = 0
x = int(input())
if x == 1:
	c = input(Colorate.Horizontal(Colors.yellow_to_green, ("Куда? > ")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Одну секунду...")))
	time.sleep(4)
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Успешно!")))
	while b == 1:
		g = input()
if x == 2:
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Тап тап тап")))
	while b == 1:
		g = input()
if x == 3:
	c = input(Colorate.Horizontal(Colors.yellow_to_green, ("Введите кол во пельменей > ")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Проверь стол!")))
	while b == 1:
		g = input()
if x == 4:
	c = input(Colorate.Horizontal(Colors.yellow_to_green, ("Введите какие то данные >")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Данные скопированы!")))
	while b == 1:
		g = input()
if x == 5:
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Наш мануал:")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("1 Юзаем 2 - 3 впна,желательно Planet vpn")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("2 Юзаем прокси")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("3 Всё делаем от лица хамстер комбат")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("4 Если что говорите что это всё хамстер комбат")))
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Мануал писал @AdvAvenger")))
	while b == 1:
		g = input()
if x == 6:
	print(Colorate.Horizontal(Colors.yellow_to_green, ("Таких функций ещё нет!")))